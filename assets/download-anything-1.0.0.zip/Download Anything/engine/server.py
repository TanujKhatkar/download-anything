#!/usr/bin/env python3
"""
Download Anything - local download engine
==========================================
Runs a tiny HTTP service on 127.0.0.1:8765 that the "Download Anything"
Chrome extension talks to. It uses yt-dlp to fetch real, playable files
from YouTube, Facebook, Instagram, X/Twitter, TikTok, Vimeo and ~1000
other sites, at the quality you pick in the extension popup.

Start it:  double-click the start script for your OS, or run
           python server.py
Stop it:   close the window (or press Ctrl+C)

Nothing leaves your computer. No accounts, no tracking, no cloud.
"""

import json
import mimetypes
import os
import re
import shutil
import sys
import tempfile
import threading
import time
import traceback
import urllib.parse
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

HOST = "127.0.0.1"
PORT = 8765
ENGINE_VERSION = "1.0.0"

# ----------------------------------------------------------------------------
# Dependencies
# ----------------------------------------------------------------------------
try:
    import yt_dlp

    YTDLP_VERSION = getattr(yt_dlp.version, "__version__", "unknown")
except Exception:  # pragma: no cover
    sys.stderr.write(
        "\n[!] yt-dlp is not installed.\n"
        "    Run:  python -m pip install -r requirements.txt\n\n"
    )
    sys.exit(1)


def find_ffmpeg():
    """System ffmpeg first, then the bundled one from imageio-ffmpeg."""
    exe = shutil.which("ffmpeg")
    if exe:
        return exe
    try:
        import imageio_ffmpeg

        exe = imageio_ffmpeg.get_ffmpeg_exe()
        if exe and os.path.exists(exe):
            return exe
    except Exception:
        pass
    return None


FFMPEG = find_ffmpeg()

# ----------------------------------------------------------------------------
# Helpers
# ----------------------------------------------------------------------------
URL_RE = re.compile(r"^https?://[^\s<>\"']+$", re.I)
ID_RE = re.compile(r"^[A-Za-z0-9_.\-]{1,64}$")

QUALITY_TIERS = [360, 480, 720, 1080, 1440, 2160]

JOBS = {}
JOBS_LOCK = threading.Lock()


def human_size(n):
    if not n:
        return ""
    n = float(n)
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024 or unit == "GB":
            return ("%.0f %s" % (n, unit)) if unit in ("B", "KB") else ("%.1f %s" % (n, unit))
        n /= 1024.0
    return ""


def clean_url(raw):
    if not raw:
        raise ValueError("No link was provided.")
    raw = urllib.parse.unquote(raw.strip().strip("\"'"))
    if not URL_RE.match(raw):
        raise ValueError("That does not look like a web link. Paste a link starting with https://")
    if len(raw) > 4096:
        raise ValueError("That link is too long.")
    return raw


def safe_name(text, limit=90):
    text = re.sub(r"[\\/:*?\"<>|\r\n\t]+", " ", text or "")
    text = re.sub(r"\s+", " ", text).strip(" .")
    return (text or "video")[:limit]



LOGIN_HINTS = (
    "log in", "login", "logged in", "logged-in", "sign in", "sign-in",
    "cookies", "empty media response", "authentication", "requires authentication",
    "rate-limit", "rate limit", "too many requests", "429", "premium",
)


def friendly(msg):
    """Turn yt-dlp noise into one short sentence a normal person understands."""
    msg = re.sub(r"\x1b\[[0-9;]*m", "", str(msg or ""))
    msg = re.sub(r"^ERROR:\s*", "", msg).strip()
    low = msg.lower()
    if any(k in low for k in LOGIN_HINTS):
        return "This one needs a logged-in session. Tick \u201cUse browser cookies\u201d and try again."
    if "private" in low or "not available" in low or "removed" in low:
        return "This post is private, removed, or blocked in your region."
    if "unsupported url" in low:
        return "That site is not supported yet."
    if "unable to extract" in low or "no video" in low or "no media" in low:
        return "No downloadable video was found on that page."
    if "404" in low or "not found" in low:
        return "That link could not be opened (404). Check the link or the post's privacy."
    if "timed out" in low or "timeout" in low or "connection" in low:
        return "The connection dropped. Check your internet and try again."
    if "geo" in low and "restrict" in low:
        return "That video is region-locked and cannot be fetched here."
    msg = re.sub(r"^\[[^\]]+\]\s*[A-Za-z0-9_-]{5,}:\s*", "", msg)
    return (msg[:240] or "That download failed. Please try again.")


CODEC_RANK = {"avc1": 4, "avc3": 4, "h264": 4, "av01": 3, "vp09": 2, "vp9": 2, "vp08": 1}


def _codec_rank(f):
    vc = (f.get("vcodec") or "").lower()
    for key, rank in CODEC_RANK.items():
        if vc.startswith(key):
            return rank
    return 1 if vc not in ("", "none") else 0


def _est_bytes(f, duration):
    """Real size if the site reports it, otherwise a bitrate-based estimate."""
    n = f.get("filesize") or f.get("filesize_approx")
    if n:
        return int(n)
    tbr = f.get("tbr") or f.get("abr") or 0
    if tbr and duration:
        return int(tbr * 1000.0 / 8.0 * duration)
    return 0


def _pick_audio(formats, video_ext, duration):
    """Best audio, preferring a codec that fits inside the video container."""
    pool = [
        f
        for f in formats
        if f.get("acodec") not in (None, "none") and f.get("vcodec") in (None, "none")
    ]
    if not pool:
        return None

    def key(f):
        ext = (f.get("ext") or "").lower()
        if video_ext == "webm":
            fits = 1 if ext in ("webm", "opus", "ogg") else 0
        else:
            fits = 1 if ext in ("m4a", "mp4", "aac") else 0
        drc = 0 if "drc" in (f.get("format_id") or "").lower() else 1
        return (fits, drc, f.get("abr") or f.get("tbr") or 0)

    return max(pool, key=key)


MEDIA_EXT = {"mp4", "webm", "m4v", "mov", "mkv"}


def _label_from_id(f):
    """Some extractors only name the resolution: 'http-720p', 'hd_1080'."""
    for field in ("format_note", "format_id"):
        val = str(f.get(field) or "")
        m = re.search(r"(\d{3,4})\s*p\b", val, re.I)
        if m:
            h = int(m.group(1))
            if 100 <= h <= 4320:
                return h
    return 0


def _nominal_height(f):
    """Resolution as users know it: the short side (works for Reels/Shorts)."""
    h = f.get("height")
    w = f.get("width")
    if h and w:
        return min(int(h), int(w))
    if h or w:
        return int(h or w)
    return _label_from_id(f)


def _entry(f, duration, audio, kind, label, height=None):
    need_audio = f.get("acodec") in (None, "none")
    size = _est_bytes(f, duration)
    ext = (f.get("ext") or "mp4").lower()
    if need_audio and audio:
        size = size + _est_bytes(audio, duration)
        aext = (audio.get("ext") or "").lower()
        if aext in ("webm", "opus", "ogg") and ext != "webm":
            ext = "webm"
    h = _nominal_height(f) if height is None else height
    return {
        "label": label,
        "sublabel": ("%dp source" % h) if h else "source file",
        "height": h,
        "format_id": f["format_id"],
        "audio_format_id": audio.get("format_id") if (need_audio and audio) else None,
        "ext": ext,
        "filesize": int(size) if size else 0,
        "filesize_human": human_size(size),
        "fps": f.get("fps"),
        "note": "video + audio" if need_audio else "ready to play",
        "kind": kind,
    }


def build_qualities(info):
    """Turn yt-dlp's format list into the short, simple list the popup shows."""
    formats = [f for f in (info.get("formats") or []) if f]
    duration = info.get("duration") or 0

    video, unknown = [], []
    for f in formats:
        ext = (f.get("ext") or "").lower()
        if ext in ("mhtml", "none"):
            continue
        if (f.get("format_note") or "").lower().startswith("storyboard"):
            continue
        vc = f.get("vcodec")
        if vc == "none":
            continue  # audio-only stream
        if vc is None:
            # Some sites (Facebook, older CDNs) hand out progressive files with
            # no codec metadata. Keep them so they are still downloadable.
            if ext in MEDIA_EXT and f.get("url"):
                unknown.append(f)
            continue
        if not (f.get("height") or f.get("width")):
            unknown.append(f)
            continue
        video.append(f)

    heights = [_nominal_height(f) for f in video]
    min_h = 300 if (heights and max(heights) >= 300) else 1

    by_height = {}
    for f in video:
        h = _nominal_height(f)
        if h < min_h:
            continue
        known = 1 if (f.get("filesize") or f.get("filesize_approx")) else 0
        cand = (_codec_rank(f), known, f.get("tbr") or 0, f.get("fps") or 0)
        cur = by_height.get(h)
        if cur is None or cand > cur[0]:
            by_height[h] = (cand, f)

    qualities = []
    for h in sorted(by_height):
        f = by_height[h][1]
        ext = (f.get("ext") or "mp4").lower()
        audio = _pick_audio(formats, ext, duration)
        if f.get("acodec") in (None, "none") and not audio:
            if unknown:
                continue  # cannot add sound, fall back to the single-file option
            continue
        label = ("%dp" % h) if h >= 100 else "SD"
        qualities.append(_entry(f, duration, audio, "tier", label, h))

    # Sites that only expose single progressive files (Facebook SD/HD, some
    # blogs and CDNs) - list them from lowest to highest.
    if not qualities and unknown:
        unknown.sort(key=lambda f: (_nominal_height(f),
                                    f.get("quality") if f.get("quality") is not None else -1,
                                    _est_bytes(f, duration)))
        n = len(unknown)
        for i, f in enumerate(unknown):
            known = _nominal_height(f)
            if i == n - 1:
                label, kind = "Original", "original"
            elif known:
                label, kind = "%dp" % known, "tier"
            elif n == 2:
                label, kind = "SD", "tier"
            else:
                label, kind = ("SD" if i == 0 else "HD"), "tier"
            qualities.append(_entry(f, duration, None, kind, label, known))

    # Original = the highest-resolution / highest-bitrate stream the site
    # itself serves, muxed with the best audio and never re-encoded.
    if qualities and not any(q["kind"] == "original" for q in qualities):
        pool = video or unknown
        if pool:
            best = None
            for f in pool:
                # highest resolution, then the heaviest stream: that is the
                # master file the site itself stores, untouched.
                cand = (_nominal_height(f), f.get("tbr") or 0,
                        f.get("quality") if f.get("quality") is not None else -1)
                if best is None or cand > best[0]:
                    best = (cand, f)
            f = best[1]
            ext = (f.get("ext") or "mp4").lower()
            audio = _pick_audio(formats, ext, duration)
            entry = _entry(f, duration, audio, "original", "Original")
            if not (f.get("acodec") in (None, "none") and not audio):
                entry["note"] = "no re-encode"
                qualities.append(entry)

    # Never offer the same stream twice. If "Original" is literally the top
    # option, keep one row and call it Original (the chip still shows the res).
    seen, out = set(), []
    for q in qualities:
        key = (q["format_id"], q["audio_format_id"])
        if key in seen:
            if out and q["kind"] == "original" and out[-1]["format_id"] == q["format_id"]:
                out[-1]["label"] = "Original"
                out[-1]["kind"] = "original"
            continue
        seen.add(key)
        out.append(q)
    for i, q in enumerate(out):
        q["order"] = i
    return out


def ydl_opts(cookies=False, extra=None):
    opts = {
        "quiet": True,
        "no_warnings": True,
        "noprogress": True,
        "noplaylist": True,
        "socket_timeout": 25,
        "retries": 3,
        "extractor_retries": 2,
        "nocheckcertificate": True,
        # keep us under the radar of the sites, still totally local
        "http_headers": {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"},
    }
    if FFMPEG:
        opts["ffmpeg_location"] = FFMPEG
    if cookies:
        opts["cookiesfrombrowser"] = (cookies if isinstance(cookies, str) else "chrome",)
    if extra:
        opts.update(extra)
    return opts


COOKIE_BROWSERS = ("chrome", "edge", "firefox", "brave", "chromium")


def extract(url, cookies=False):
    """Read a page (no download). With cookies=True, reuse the user's own
    logged-in browser session, trying each installed browser in turn."""
    attempts = list(COOKIE_BROWSERS) if cookies else [False]
    last = None
    for browser in attempts:
        try:
            with yt_dlp.YoutubeDL(ydl_opts(browser, {"skip_download": True})) as ydl:
                info = ydl.extract_info(url, download=False)
            if info is None:
                raise RuntimeError("Nothing could be read from that link.")
            if info.get("_type") == "playlist":
                entries = [e for e in (info.get("entries") or []) if e]
                if not entries:
                    raise RuntimeError("That link has no downloadable video.")
                info = entries[0]
            return info
        except Exception as e:  # try the next browser, remember the error
            last = e
    raise last if last else RuntimeError("That link could not be read.")


def build_format_string(q):
    vid = q["format_id"]
    aid = q.get("audio_format_id")
    if not ID_RE.match(vid):
        raise ValueError("Bad format id.")
    if aid:
        if not ID_RE.match(aid):
            raise ValueError("Bad audio format id.")
        return "%s+%s/%s/b" % (vid, aid, vid)
    return "%s/b" % vid


# ----------------------------------------------------------------------------
# Background download jobs
# ----------------------------------------------------------------------------
def start_job(url, quality, cookies):
    job_id = uuid.uuid4().hex[:16]
    job = {
        "id": job_id,
        "state": "preparing",
        "progress": 0.0,
        "speed": "",
        "eta": "",
        "error": None,
        "path": None,
        "filename": None,
        "filesize": 0,
        "label": quality.get("label", "video"),
        "created": time.time(),
        "served": False,
    }
    with JOBS_LOCK:
        JOBS[job_id] = job

    t = threading.Thread(target=_run_job, args=(job, url, quality, cookies), daemon=True)
    t.start()
    return job


def _run_job(job, url, quality, cookies):
    workdir = tempfile.mkdtemp(prefix="dla_")
    try:
        fmt = build_format_string(quality)
        container = quality.get("ext") or "mp4"
        if container in ("m4v", "mov"):
            container = "mp4"

        def hook(d):
            if d.get("status") == "downloading":
                total = d.get("total_bytes") or d.get("total_bytes_estimate") or 0
                got = d.get("downloaded_bytes") or 0
                if total:
                    job["progress"] = min(99.0, round(got * 100.0 / total, 1))
                sp = d.get("speed")
                if sp:
                    job["speed"] = human_size(sp) + "/s"
                eta = d.get("eta")
                if eta:
                    job["eta"] = "%ds" % int(eta)
            elif d.get("status") == "finished":
                job["progress"] = 99.0

        attempts = list(COOKIE_BROWSERS) if cookies else [False]
        info = None
        last = None
        for browser in attempts:
            opts = ydl_opts(
                browser,
                {
                    "format": fmt,
                    "outtmpl": os.path.join(workdir, "%(title).120B.%(ext)s"),
                    "merge_output_format": container,
                    "progress_hooks": [hook],
                    "windowsfilenames": True,
                },
            )
            try:
                with yt_dlp.YoutubeDL(opts) as ydl:
                    info = ydl.extract_info(url, download=True)
                last = None
                break
            except Exception as e:  # wrong browser session? try the next one
                last = e
                for f in os.listdir(workdir):
                    fp = os.path.join(workdir, f)
                    if os.path.isfile(fp):
                        try:
                            os.remove(fp)
                        except Exception:
                            pass
        if last is not None:
            raise last
        if info is None:
            raise RuntimeError("The site did not return a file.")

        if info.get("_type") == "playlist":
            entries = [e for e in (info.get("entries") or []) if e]
            info = entries[0] if entries else info

        files = [
            os.path.join(workdir, f)
            for f in os.listdir(workdir)
            if os.path.isfile(os.path.join(workdir, f)) and not f.endswith((".part", ".ytdl", ".temp"))
        ]
        if not files:
            raise RuntimeError("The site did not return a file. Try again or pick a lower quality.")
        path = max(files, key=os.path.getsize)

        ext = os.path.splitext(path)[1].lstrip(".") or "mp4"
        title = safe_name(info.get("title") or "video")
        if quality.get("kind") == "original":
            suffix = "Original" + ((" %dp" % quality["height"]) if quality.get("height") else "")
        else:
            suffix = quality.get("label") or "video"
        nice = safe_name("%s - %s" % (title, suffix), 120) + "." + ext

        final = os.path.join(workdir, nice)
        try:
            if os.path.abspath(path) != os.path.abspath(final):
                os.replace(path, final)
        except Exception:
            final = path

        job["path"] = final
        job["filename"] = os.path.basename(final)
        job["filesize"] = os.path.getsize(final)
        job["progress"] = 100.0
        job["speed"] = ""
        job["eta"] = ""
        job["state"] = "ready"
    except Exception as e:  # noqa: BLE001
        job["error"] = friendly(str(e) or e.__class__.__name__)
        job["state"] = "error"
        try:
            shutil.rmtree(workdir, ignore_errors=True)
        except Exception:
            pass


def sweep_jobs(max_age=60 * 60):
    """Delete temp files older than an hour, or already served jobs."""
    now = time.time()
    with JOBS_LOCK:
        for jid, job in list(JOBS.items()):
            old = (now - job["created"]) > max_age
            if old or (job.get("served") and (now - job["created"]) > 120):
                path = job.get("path")
                if path and os.path.exists(path):
                    try:
                        shutil.rmtree(os.path.dirname(path), ignore_errors=True)
                    except Exception:
                        pass
                JOBS.pop(jid, None)


# ----------------------------------------------------------------------------
# HTTP layer
# ----------------------------------------------------------------------------
class Handler(BaseHTTPRequestHandler):
    server_version = "DownloadAnything/" + ENGINE_VERSION
    protocol_version = "HTTP/1.1"

    # -- plumbing ----------------------------------------------------------
    def log_message(self, fmt, *args):  # keep the console calm
        if os.environ.get("DLA_DEBUG"):
            sys.stderr.write("%s - %s\n" % (self.address_string(), fmt % args))

    def _cors(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Access-Control-Allow-Private-Network", "true")
        self.send_header("Cache-Control", "no-store")

    def _json(self, obj, status=200):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self._cors()
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _err(self, msg, status=400):
        self._json({"ok": False, "error": msg}, status)

    def do_OPTIONS(self):  # noqa: N802
        self.send_response(204)
        self._cors()
        self.send_header("Content-Length", "0")
        self.end_headers()

    def do_GET(self):  # noqa: N802
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path.rstrip("/") or "/"
        qs = urllib.parse.parse_qs(parsed.query)
        try:
            if path in ("/", "/health"):
                return self._json(
                    {
                        "ok": True,
                        "engine": "Download Anything",
                        "version": ENGINE_VERSION,
                        "ytdlp": YTDLP_VERSION,
                        "ffmpeg": bool(FFMPEG),
                        "ffmpeg_path": FFMPEG or "",
                        "max_quality": "2160p (4K)" if FFMPEG else "720p (install ffmpeg for 1080p/4K)",
                    }
                )
            if path == "/info":
                return self.api_info(qs)
            if path == "/prepare":
                return self.api_prepare(qs)
            if path == "/job":
                return self.api_job(qs)
            if path == "/file":
                return self.api_file(qs)
            return self._err("Unknown endpoint.", 404)
        except ValueError as e:
            return self._err(str(e), 400)
        except Exception as e:  # noqa: BLE001
            if os.environ.get("DLA_DEBUG"):
                traceback.print_exc()
            return self._err(friendly(str(e)), 502)

    # -- endpoints ---------------------------------------------------------
    def api_info(self, qs):
        url = clean_url((qs.get("url") or [""])[0])
        cookies = (qs.get("cookies") or ["0"])[0] == "1"
        sweep_jobs()
        info = extract(url, cookies)
        qualities = build_qualities(info)
        if not qualities:
            raise RuntimeError("No video stream was found for that link.")
        dur = info.get("duration")
        return self._json(
            {
                "ok": True,
                "title": info.get("title") or "Untitled video",
                "uploader": info.get("uploader") or info.get("channel") or "",
                "duration": int(dur) if dur else 0,
                "duration_text": time.strftime("%H:%M:%S", time.gmtime(int(dur))) if dur else "",
                "extractor": info.get("extractor_key") or "",
                "webpage_url": info.get("webpage_url") or url,
                "qualities": qualities,
            }
        )

    def api_prepare(self, qs):
        url = clean_url((qs.get("url") or [""])[0])
        cookies = (qs.get("cookies") or ["0"])[0] == "1"
        vid = (qs.get("vid") or [""])[0]
        aid = (qs.get("aid") or [""])[0]
        label = (qs.get("label") or ["video"])[0][:24]
        kind = (qs.get("kind") or ["tier"])[0]
        height = int((qs.get("height") or ["0"])[0] or 0)
        ext = (qs.get("ext") or ["mp4"])[0].lower()
        if ext not in ("mp4", "webm", "mkv", "m4v", "mov"):
            ext = "mp4"
        if not ID_RE.match(vid):
            raise ValueError("Missing or invalid quality id.")
        if aid and not ID_RE.match(aid):
            raise ValueError("Missing or invalid audio id.")
        quality = {
            "format_id": vid,
            "audio_format_id": aid or None,
            "label": label,
            "kind": kind,
            "height": height,
            "ext": ext,
        }
        sweep_jobs()
        job = start_job(url, quality, cookies)
        return self._json(
            {"ok": True, "job_id": job["id"], "label": label, "state": job["state"]}
        )

    def api_job(self, qs):
        jid = (qs.get("id") or [""])[0]
        with JOBS_LOCK:
            job = JOBS.get(jid)
        if not job:
            raise ValueError("That download session expired. Please try again.")
        return self._json(
            {
                "ok": True,
                "id": job["id"],
                "state": job["state"],
                "progress": job["progress"],
                "speed": job["speed"],
                "eta": job["eta"],
                "filename": job["filename"],
                "filesize": job["filesize"],
                "filesize_human": human_size(job["filesize"]),
                "error": job["error"],
            }
        )

    def api_file(self, qs):
        jid = (qs.get("id") or [""])[0]
        with JOBS_LOCK:
            job = JOBS.get(jid)
        if not job or job["state"] != "ready" or not job.get("path"):
            raise ValueError("That file is not ready yet.")
        path = job["path"]
        if not os.path.exists(path):
            raise ValueError("That file has expired. Please download it again.")

        size = os.path.getsize(path)
        ctype = mimetypes.guess_type(path)[0] or "application/octet-stream"
        quoted = urllib.parse.quote(job["filename"])
        self.send_response(200)
        self._cors()
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(size))
        self.send_header(
            "Content-Disposition",
            "attachment; filename=\"%s\"; filename*=UTF-8''%s"
            % (re.sub(r"[^A-Za-z0-9._ -]", "_", job["filename"]), quoted),
        )
        self.end_headers()
        try:
            with open(path, "rb") as fh:
                shutil.copyfileobj(fh, self.wfile, 1024 * 256)
        except (BrokenPipeError, ConnectionResetError):
            pass
        finally:
            job["served"] = True


class Server(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True


BANNER = r"""
  ____                      _                 _   _             _
 |  _ \  _____      ___ __ | | __ _ _ __   __| | / \   _ __  _ __ | |_ ___
 | | | |/ _ \ \ /\ / / '_ \| |/ _` | '_ \ / _` |/ _ \ | '_ \| '_ \| __/ _ \
 | |_| | (_) \ V  V /| | | | | (_| | | | | (_| / ___ \| | | | | | | ||  __/
 |____/ \___/ \_/\_/ |_| |_|_|\__,_|_| |_|\__,_/_/   \_\_| |_|_| |_|\__\___|

  Download whatever you see in 4K  -  engine v%s
"""


def main():
    port = PORT
    if len(sys.argv) > 1:
        try:
            port = int(sys.argv[1])
        except ValueError:
            pass

    print(BANNER % ENGINE_VERSION)
    print("  yt-dlp  : %s" % YTDLP_VERSION)
    print("  ffmpeg  : %s" % (FFMPEG if FFMPEG else "NOT FOUND - 1080p/4K merging unavailable"))
    print("  listening: http://%s:%d" % (HOST, port))
    print("\n  Keep this window open while you download.")
    print("  Close it (or press Ctrl+C) when you are done.\n")

    try:
        httpd = Server((HOST, port), Handler)
    except OSError as e:
        print("  [!] Port %d is already in use (%s)." % (port, e.strerror or e))
        print("      Another copy of Download Anything may already be running.")
        print("      Close that window, or restart your computer, then try again.")
        try:
            input("\n  Press Enter to close...")
        except Exception:
            pass
        return

    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\n  Stopped. Bye!")
    finally:
        httpd.server_close()


if __name__ == "__main__":
    main()
