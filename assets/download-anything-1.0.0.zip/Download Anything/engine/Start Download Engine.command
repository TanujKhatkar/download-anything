#!/usr/bin/env bash
# Download Anything - local engine launcher (macOS / Linux)
cd "$(dirname "$0")" || exit 1
PY=python3
command -v python3 >/dev/null 2>&1 || PY=python
command -v "$PY" >/dev/null 2>&1 || { echo "Python 3 not found. Install it from https://python.org"; exit 1; }

if ! "$PY" -c "import yt_dlp, imageio_ffmpeg" >/dev/null 2>&1; then
  echo "First run: installing downloader components (one time only)..."
  "$PY" -m pip install --quiet --upgrade -r requirements.txt || {
    echo "Install failed. Try: $PY -m pip install --user -r requirements.txt"; exit 1; }
fi

"$PY" server.py
