// Download Anything — background service worker
// Keeps downloads alive even after the popup closes.

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.get({ cookies: false }, (v) => {
    chrome.storage.local.set({ cookies: v.cookies });
  });
});

function sanitize(name) {
  const base = String(name || "video.mp4")
    .replace(/[\\/:*?"<>|\u0000-\u001f]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
  return (base || "video.mp4").slice(0, 150);
}

async function doDownload(msg) {
  try {
    if (!msg || !msg.url) throw new Error("No file URL.");
    const id = await chrome.downloads.download({
      url: msg.url,
      filename: sanitize(msg.filename),
      saveAs: false,
      conflictAction: "uniquify",
    });
    return { ok: true, id };
  } catch (err) {
    return { ok: false, error: (err && err.message) || "Chrome could not start that download." };
  }
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg && msg.type === "download") {
    doDownload(msg).then(sendResponse);
    return true; // async response
  }
  return false;
});
