@echo off
title Download Anything - Engine
cd /d "%~dp0"
echo.
echo   Download Anything - starting the local engine...
echo.

set "PY="
where py >nul 2>nul
if %errorlevel%==0 set "PY=py"
if not defined PY (
  where python >nul 2>nul
  if %errorlevel%==0 set "PY=python"
)
if not defined PY (
  echo   [!] Python 3 was not found on this PC.
  echo.
  echo   Install it from https://www.python.org/downloads/
  echo   IMPORTANT: tick "Add python.exe to PATH" during setup.
  echo.
  pause
  exit /b 1
)

%PY% -c "import yt_dlp, imageio_ffmpeg" >nul 2>nul
if not %errorlevel%==0 (
  echo   First run: installing the downloader components ^(one time only^)...
  %PY% -m pip install --quiet --upgrade -r requirements.txt
  if not %errorlevel%==0 (
    echo.
    echo   [!] Install failed. Try running this file as Administrator.
    pause
    exit /b 1
  )
)

%PY% server.py
echo.
echo   Engine stopped.
pause
