# Download Anything

**Download whatever you see in 4K**

A Chrome extension with a dead-simple popup — paste a link, press **Paste**, pick a
quality, done — backed by a tiny local engine that really downloads the file.

```
+-----------------------------+        http://127.0.0.1:8765        +------------------+
|  Chrome extension (popup)   |  <------------------------------->  |  Local engine    |
|  paste -> pick quality      |                                     |  yt-dlp + ffmpeg |
+-----------------------------+                                     +--------+
                                                                             |
                                                    saves a real .mp4 to Downloads
```

## What you get

| | |
|---|---|
| **One input bar** | Paste a link, **Paste** button sits on the right of it |
| **Video qualities only** | 360p, 480p, 720p, 1080p, 1440p (2K), 2160p (4K) — only what that video has |
| **Original** | The untouched best stream the site serves, never re-encoded |
| **Real files** | Proper `.mp4` / `.webm` with picture **and** sound merged |
| **Sites** | YouTube, Facebook, Instagram, X/Twitter, TikTok, Vimeo, Reddit, LinkedIn, Pinterest, Twitch, 1000+ more |
| **Private** | Everything runs on your machine. No accounts, no servers, no tracking |

No audio-only buttons, no format tables, no clutter. One bar, one list, one download.

## Install

1. **Extension** — `chrome://extensions` → enable **Developer mode** → **Load unpacked** →
   choose the `extension` folder → pin the icon.
2. **Engine** — in the `engine` folder:
   - Windows: double-click **`Start Download Engine.bat`**
   - macOS: double-click **`Start Download Engine.command`**
   - Linux: `bash start.sh`
   
   First launch installs `yt-dlp` + `ffmpeg` automatically (needs Python 3).
   Leave the window open; close it when you're done.

Full walkthrough: **`INSTALL - START HERE.txt`**

## Use

1. Copy a video / post link.
2. Click the extension icon, then **Paste** (or Ctrl+V and Enter).
3. Pick a quality → the file lands in your **Downloads** folder.

If you open the popup while already on a YouTube / Instagram / X video page, the
link is filled in for you.

## Good to know

- **Private or age-restricted posts** → tick **Use browser cookies** in the popup.
  This reuses your existing Chrome session *locally* so the engine is allowed to see
  the post. Nothing is uploaded.
- **Engine not running?** The popup tells you, with the fix in one tap.
- **Site changed and a download fails?** Update the engine:
  `python -m pip install -U yt-dlp`
- **DRM content** (Netflix, Prime Video, Disney+, paid Spotify) is not supported —
  no downloader can legally or technically handle those.
- Personal use only. Respect copyright and each site's terms.

## How it is built

```
extension/                 Manifest V3
  manifest.json            permissions: activeTab, clipboardRead, downloads, scripting, storage
  popup.html/.css/.js      the whole UI; plain JS, no frameworks, no remote code
  background.js            service worker that hands finished files to chrome.downloads
  icons/                   16 / 32 / 48 / 128 px

engine/
  server.py                zero-dependency HTTP service on 127.0.0.1:8765
                           /health  /info  /prepare  /job  /file
  requirements.txt         yt-dlp + imageio-ffmpeg
  Start Download Engine.bat / .command / start.sh
```

The popup never touches video sites directly (browsers cannot, because of CORS,
signed URLs and DRM). It asks the engine for the *quality list* of a link, then asks
the engine to prepare the chosen one, polls progress, and hands the finished file to
Chrome's own download manager.

## Local API (for the curious)

| Endpoint | Purpose |
|---|---|
| `GET /health` | engine alive? version, ffmpeg present |
| `GET /info?url=…` | title, duration, uploader and the quality list |
| `GET /prepare?url=…&vid=…&aid=…&label=…&kind=…&height=…&ext=…` | start a job |
| `GET /job?id=…` | state, progress %, speed, ETA |
| `GET /file?id=…` | the finished file (`Content-Disposition: attachment`) |

## Tested

Everything below was run against a live engine and a real Chromium instance:

- Engine: health, info, prepare, progress polling, file streaming, size/type headers
- Real files verified with ffprobe (video + audio streams, correct resolution)
- YouTube: Big Buck Bunny 4K (360p→4K + Original), 720p merge, low-res source
- X/Twitter, Facebook (SD/HD), TikTok: real downloads, correct containers
- Instagram / Vimeo without a session: friendly "needs a logged-in session" message
- Extension loaded as a **real MV3 extension**: manifest, service worker, host
  permission, clipboard **Paste**, options list, `chrome.downloads` entry completed
  (28.8 MB `video/mp4`), zero JS errors
