/* Download Anything — popup logic
   Flow: paste link -> pick quality -> engine prepares file -> Chrome saves it. */

const ENGINE = "http://127.0.0.1:8765";

const $ = (id) => document.getElementById(id);
const ui = {
  url: $("url"),
  paste: $("paste"),
  go: $("go"),
  msg: $("msg"),
  result: $("result"),
  title: $("title"),
  sub: $("sub"),
  qualities: $("qualities"),
  progress: $("progress"),
  pLabel: $("pLabel"),
  pPct: $("pPct"),
  pFill: $("pFill"),
  pHint: $("pHint"),
  pCancel: $("pCancel"),
  offline: $("offline"),
  directBtn: $("directBtn"),
  dot: $("dot"),
  engineText: $("engineText"),
  cookies: $("cookies"),
};

const VIDEO_HOSTS = [
  "youtube.com", "youtu.be", "m.youtube.com", "music.youtube.com",
  "instagram.com", "facebook.com", "fb.watch", "m.facebook.com",
  "x.com", "twitter.com", "t.co",
  "tiktok.com", "vimeo.com", "dailymotion.com", "twitch.tv",
  "reddit.com", "redd.it", "pinterest.com", "linkedin.com",
  "snapchat.com", "threads.net", "bilibili.com", "rumble.com",
  "streamable.com", "soundcloud.com", "imgur.com", "9gag.com",
];

let busy = false;
let currentUrl = "";
let currentInfo = null;
let pollTimer = null;

/* ------------------------------------------------------------------ utils */
function showMsg(text, kind = "error") {
  if (!text) {
    ui.msg.hidden = true;
    return;
  }
  ui.msg.textContent = text;
  ui.msg.className = "msg" + (kind === "info" ? " info" : "");
  ui.msg.hidden = false;
}

function normalizeUrl(raw) {
  let v = String(raw || "").trim();
  if (!v) return "";
  if (/^[a-z]+:\/\//i.test(v) === false) v = "https://" + v;
  return v;
}

function looksLikeLink(v) {
  try {
    const u = new URL(v);
    return (u.protocol === "http:" || u.protocol === "https:") && /\.[a-z]{2,}/i.test(u.hostname);
  } catch {
    return false;
  }
}

function hostOf(v) {
  try {
    return new URL(v).hostname.replace(/^www\./, "").toLowerCase();
  } catch {
    return "";
  }
}

function isVideoSite(v) {
  const h = hostOf(v);
  return VIDEO_HOSTS.some((d) => h === d || h.endsWith("." + d));
}

function humanSize(n) {
  if (!n) return "";
  const units = ["B", "KB", "MB", "GB"];
  let i = 0;
  let x = Number(n);
  while (x >= 1024 && i < units.length - 1) {
    x /= 1024;
    i++;
  }
  return (i < 2 ? Math.round(x) : x.toFixed(1)) + " " + units[i];
}

async function api(path, timeoutMs = 120000) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const res = await fetch(ENGINE + path, { signal: ctrl.signal, cache: "no-store" });
    let data = {};
    try {
      data = await res.json();
    } catch {
      /* ignore */
    }
    if (!res.ok || data.ok === false) {
      throw new Error(data.error || "Engine returned " + res.status + ".");
    }
    return data;
  } catch (err) {
    if (err && err.name === "AbortError") {
      throw new Error("The engine stopped responding. Try again.");
    }
    if (err instanceof TypeError) {
      const e = new Error("ENGINE_OFFLINE");
      e.code = "ENGINE_OFFLINE";
      throw e;
    }
    throw err;
  } finally {
    clearTimeout(timer);
  }
}

function setBusy(state) {
  busy = state;
  ui.go.disabled = state;
  ui.paste.disabled = state;
  ui.url.disabled = state;
  ui.qualities.querySelectorAll(".q").forEach((b) => (b.disabled = state));
}

/* --------------------------------------------------------- engine status */
async function checkEngine(quiet = true) {
  try {
    const h = await api("/health", 4000);
    ui.dot.className = "dot ok";
    ui.engineText.textContent = h.ffmpeg ? "Engine ready · up to 4K" : "Engine ready · up to 720p";
    ui.engineText.title = "yt-dlp " + (h.ytdlp || "") + (h.ffmpeg ? " · ffmpeg found" : " · ffmpeg missing");
    ui.offline.hidden = true;
    return true;
  } catch {
    ui.dot.className = "dot bad";
    ui.engineText.textContent = "Engine not running";
    ui.engineText.title = "";
    ui.offline.hidden = false;
    if (!quiet) showMsg("Start the engine first, then press Get download options again.");
    return false;
  }
}

/* --------------------------------------------------------------- render */
function renderQualities(info) {
  const wrap = ui.qualities;
  wrap.textContent = "";

  // the engine already sorted them low -> high, Original last
  const list = (info.qualities || []).slice().sort((a, b) => {
    const ao = typeof a.order === "number" ? a.order : a.height;
    const bo = typeof b.order === "number" ? b.order : b.height;
    return ao - bo;
  });

  if (!list.length) {
    showMsg("No downloadable video was found on that page.");
    return;
  }

  list.forEach((q) => {
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "q" + (q.kind === "original" ? " original" : "");
    btn.dataset.label = q.label;

    const left = document.createElement("span");
    left.className = "q-label";

    if (q.kind === "original") {
      left.textContent = "Original quality";
      if (q.sublabel) {
        const chip = document.createElement("span");
        chip.className = "chip";
        chip.textContent = q.sublabel.replace(" source", "");
        left.appendChild(chip);
      }
    } else {
      left.textContent = q.label;
      if (q.height >= 2160) {
        const chip = document.createElement("span");
        chip.className = "chip";
        chip.textContent = "4K";
        left.appendChild(chip);
      } else if (q.height >= 1440) {
        const chip = document.createElement("span");
        chip.className = "chip";
        chip.textContent = "2K";
        left.appendChild(chip);
      }
    }

    const right = document.createElement("span");
    right.className = "q-size";
    right.textContent = q.filesize_human ? "~" + q.filesize_human : "";

    btn.append(left, right);
    btn.addEventListener("click", () => startDownload(q));
    wrap.appendChild(btn);
  });
}

function showProgress(label) {
  ui.qualities.hidden = true;
  ui.progress.hidden = false;
  ui.pLabel.textContent = "Preparing " + label;
  ui.pPct.textContent = "0%";
  ui.pFill.style.width = "0%";
  ui.pHint.textContent = "Getting the file ready…";
}

function hideProgress() {
  ui.qualities.hidden = false;
  ui.progress.hidden = true;
  if (pollTimer) {
    clearInterval(pollTimer);
    pollTimer = null;
  }
}

/* -------------------------------------------------------------- fetching */
async function loadOptions(rawUrl) {
  if (busy) return;
  const url = normalizeUrl(rawUrl);
  if (!url) {
    showMsg("Paste a link first.");
    ui.url.focus();
    return;
  }
  if (!looksLikeLink(url)) {
    showMsg("That is not a valid link. It should look like https://…");
    return;
  }

  if (!(await checkEngine(false))) return;

  showMsg("");
  ui.result.hidden = true;
  ui.go.disabled = true;
  ui.go.textContent = "Reading the video…";

  try {
    const q = "/info?url=" + encodeURIComponent(url) + "&cookies=" + (ui.cookies.checked ? "1" : "0");
    const info = await api(q, 120000);

    currentUrl = url;
    currentInfo = info;

    ui.title.textContent = info.title || "Untitled video";
    const bits = [];
    if (info.duration_text) bits.push(info.duration_text.replace(/^00:/, ""));
    if (info.uploader) bits.push(info.uploader);
    if (info.extractor) bits.push(info.extractor);
    ui.sub.textContent = bits.join(" · ");

    renderQualities(info);
    ui.result.hidden = false;
  } catch (err) {
    if (err.code === "ENGINE_OFFLINE") {
      checkEngine(false);
      return;
    }
    showMsg(err.message || "Could not read that link.");
  } finally {
    ui.go.disabled = false;
    ui.go.textContent = "Get download options";
  }
}

/* ------------------------------------------------------------- download */
async function startDownload(q) {
  if (busy || !currentUrl) return;
  setBusy(true);
  showMsg("");
  showProgress(q.label + (q.kind === "original" ? " (original)" : ""));

  try {
    const params = new URLSearchParams({
      url: currentUrl,
      vid: q.format_id,
      aid: q.audio_format_id || "",
      label: q.label,
      kind: q.kind || "tier",
      height: String(q.height || 0),
      cookies: ui.cookies.checked ? "1" : "0",
    });

    const prep = await api("/prepare?" + params.toString(), 60000);
    const jobId = prep.job_id;

    const done = await watchJob(jobId, q.label);
    hideProgress();

    if (done.state !== "ready") {
      showMsg(done.error || "That download failed.");
      setBusy(false);
      return;
    }

    ui.pHint.textContent = "Saving to your Downloads folder…";
    const res = await sendToBackground({
      type: "download",
      url: ENGINE + "/file?id=" + encodeURIComponent(jobId),
      filename: done.filename || "video.mp4",
    });

    if (res && res.ok) {
      showMsg("Saved to Downloads — " + (done.filename || "your file"), "info");
    } else {
      showMsg((res && res.error) || "Chrome could not save that file.");
    }
  } catch (err) {
    hideProgress();
    if (err.code === "ENGINE_OFFLINE") {
      showMsg("The engine stopped. Start it again and retry.");
      checkEngine(true);
    } else {
      showMsg(err.message || "Something went wrong.");
    }
  } finally {
    setBusy(false);
  }
}

function watchJob(jobId, label) {
  return new Promise((resolve, reject) => {
    const started = Date.now();
    let downloading = false;
    pollTimer = setInterval(async () => {
      try {
        const job = await api("/job?id=" + encodeURIComponent(jobId), 20000);

        const pct = Math.max(0, Math.min(100, Math.round(job.progress || 0)));
        ui.pPct.textContent = pct + "%";
        ui.pFill.style.width = pct + "%";

        if (downloading === false && job.progress > 0) {
          downloading = true;
          ui.pLabel.textContent = "Downloading " + (label || "video");
        }
        if (job.state === "ready") {
          clearInterval(pollTimer);
          pollTimer = null;
          ui.pPct.textContent = "100%";
          ui.pFill.style.width = "100%";
          resolve(job);
          return;
        }
        if (job.state === "error") {
          clearInterval(pollTimer);
          pollTimer = null;
          resolve(job);
          return;
        }
        if (job.speed) {
          ui.pHint.textContent = job.speed + (job.eta ? " · " + job.eta + " left" : "");
        }
        if (Date.now() - started > 20 * 60 * 1000) {
          clearInterval(pollTimer);
          pollTimer = null;
          reject(new Error("That took too long. Try a lower quality."));
        }
      } catch (err) {
        clearInterval(pollTimer);
        pollTimer = null;
        reject(err);
      }
    }, 900);
  });
}

function sendToBackground(msg) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage(msg, (res) => {
      if (chrome.runtime.lastError) {
        resolve({ ok: false, error: chrome.runtime.lastError.message });
      } else {
        resolve(res);
      }
    });
  });
}

/* ---------------------------------------------------------- page fallback */
async function grabFromPage() {
  showMsg("");
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab || !tab.id) throw new Error("No active tab.");

    const [{ result }] = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => {
        const out = [];
        const push = (u) => {
          if (!u) return;
          try {
            const abs = new URL(u, location.href).href;
            if (/^https?:/i.test(abs) && !out.includes(abs)) out.push(abs);
          } catch {
            /* ignore */
          }
        };
        document.querySelectorAll("video").forEach((v) => {
          push(v.currentSrc || v.src);
          v.querySelectorAll("source").forEach((s) => push(s.src));
        });
        document.querySelectorAll('meta[property="og:video"], meta[property="og:video:url"], meta[property="og:video:secure_url"]').forEach((m) => push(m.content));
        document.querySelectorAll("a[href]").forEach((a) => {
          if (/\.(mp4|webm|mov|m4v)(\?|$)/i.test(a.href)) push(a.href);
        });
        return out.filter((u) => !/\.m3u8(\?|$)/i.test(u)).slice(0, 8);
      },
    });

    const links = (result || []).filter((u) => /\.(mp4|webm|mov|m4v)(\?|$)/i.test(u));
    if (!links.length) {
      showMsg("This page hides its video behind a stream, so the engine is needed. Start it and try the link again.");
      return;
    }
    showMsg("");
    ui.qualities.textContent = "";
    ui.title.textContent = "Media on this page";
    ui.sub.textContent = links.length + " direct file" + (links.length > 1 ? "s" : "") + " found";
    links.forEach((link, i) => {
      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = "q";
      btn.innerHTML = "";
      const l = document.createElement("span");
      l.className = "q-label";
      l.textContent = "File " + (i + 1) + " · Original";
      const r = document.createElement("span");
      r.className = "q-size";
      r.textContent = link.split("/").pop().split("?")[0].slice(0, 22);
      btn.append(l, r);
      btn.addEventListener("click", async () => {
        const res = await sendToBackground({ type: "download", url: link, filename: link.split("/").pop().split("?")[0] });
        if (res && res.ok) showMsg("Saved to Downloads.", "info");
        else showMsg((res && res.error) || "Chrome could not save that file.");
      });
      ui.qualities.appendChild(btn);
    });
    ui.result.hidden = false;
  } catch (err) {
    showMsg(err.message || "Could not read this page.");
  }
}

/* ------------------------------------------------------------- lifecycle */
function initEvents() {
  ui.paste.addEventListener("click", async () => {
    try {
      const text = (await navigator.clipboard.readText()).trim();
      if (!text) {
        showMsg("Your clipboard is empty. Copy a video link first.");
        return;
      }
      ui.url.value = text;
      loadOptions(text);
    } catch {
      showMsg("Chrome blocked clipboard access. Click the box and press Ctrl+V.");
      ui.url.focus();
    }
  });

  ui.go.addEventListener("click", () => loadOptions(ui.url.value));

  ui.url.addEventListener("keydown", (e) => {
    if (e.key === "Enter") {
      e.preventDefault();
      loadOptions(ui.url.value);
    }
  });

  ui.url.addEventListener("input", () => showMsg(""));

  ui.pCancel.addEventListener("click", () => {
    hideProgress();
    setBusy(false);
    ui.pHint.textContent = "";
  });

  ui.directBtn.addEventListener("click", grabFromPage);

  ui.cookies.addEventListener("change", () => {
    chrome.storage.local.set({ cookies: ui.cookies.checked });
  });
}

async function init() {
  initEvents();

  chrome.storage.local.get({ cookies: false }, (v) => {
    ui.cookies.checked = !!v.cookies;
  });

  checkEngine(true);

  // Smart start: if the tab you are on is a video site, fill it in for you.
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab && tab.url && /^https?:/i.test(tab.url) && isVideoSite(tab.url)) {
      ui.url.value = tab.url;
      loadOptions(tab.url);
    }
  } catch {
    /* activeTab not granted — no problem */
  }

  setTimeout(() => ui.url.focus(), 120);
}

document.addEventListener("DOMContentLoaded", init);
